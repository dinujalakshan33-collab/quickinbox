const $ = (id) => document.getElementById(id);
const state = { address: null, token: null, expiresAt: null, timerId: null, pollId: null, messages: [] };
const saved = sessionStorage.getItem("qi_session");
if (saved) { try { Object.assign(state, JSON.parse(saved)); } catch {} }
$("year").textContent = new Date().getFullYear();
let toastTimeout;
function toast(message) {
  $("toast").textContent = message; $("toast").classList.add("show");
  clearTimeout(toastTimeout); toastTimeout = setTimeout(() => $("toast").classList.remove("show"), 2500);
}
function save() {
  if (state.address && state.token) sessionStorage.setItem("qi_session", JSON.stringify({address:state.address,token:state.token,expiresAt:state.expiresAt}));
  else sessionStorage.removeItem("qi_session");
}
function authHeaders() { return { "Authorization": `Bearer ${state.token}` }; }
function setBusy(busy) { $("createBtn").disabled = busy || !!state.address; $("createBtn").textContent = busy ? "Creating…" : "✦ Create inbox"; }
function showAddress() {
  $("address").textContent = state.address || "Tap “Create inbox” to begin";
  $("copyBtn").disabled = !state.address; $("refreshBtn").disabled = !state.address; $("deleteBtn").disabled = !state.address;
  setBusy(false); updateTimer();
}
async function createInbox() {
  setBusy(true); $("status").textContent = "Creating a secure inbox…";
  try {
    const r = await fetch("/api/inboxes", {method:"POST"});
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Could not create inbox.");
    state.address = data.address; state.token = data.token; state.expiresAt = data.expiresAt; state.messages = [];
    save(); showAddress(); renderMessages([]); startPolling(); toast("Your temporary inbox is ready.");
    $("status").textContent = "Ready to receive email.";
  } catch(e) { $("status").textContent = e.message; toast(e.message); setBusy(false); }
}
function updateTimer() {
  if (!state.expiresAt) { $("timer").textContent = "—"; return; }
  const left = Math.max(0, state.expiresAt - Date.now());
  const mins = Math.floor(left / 60000), secs = Math.floor(left % 60000 / 1000);
  $("timer").textContent = `${String(mins).padStart(2,"0")}:${String(secs).padStart(2,"0")}`;
  if (!left) expireLocal();
}
function expireLocal() {
  stopPolling(); state.address = state.token = state.expiresAt = null; state.messages = []; save(); showAddress(); renderMessages([]);
  $("status").textContent = "This inbox has expired. Create a new one.";
}
async function copyAddress() {
  if (!state.address) return;
  try { await navigator.clipboard.writeText(state.address); toast("Email address copied."); }
  catch { const t = document.createElement("textarea"); t.value = state.address; document.body.appendChild(t); t.select(); document.execCommand("copy"); t.remove(); toast("Email address copied."); }
}
function stopPolling() { if (state.pollId) clearInterval(state.pollId); if (state.timerId) clearInterval(state.timerId); state.pollId = state.timerId = null; }
function startPolling() {
  stopPolling(); state.timerId = setInterval(updateTimer, 1000); pollMessages(); state.pollId = setInterval(pollMessages, 5000);
}
async function pollMessages() {
  if (!state.address || !state.token) return;
  try {
    const r = await fetch(`/api/inboxes/${encodeURIComponent(state.address)}/messages`, {headers:authHeaders()});
    const data = await r.json();
    if (!r.ok) { if (r.status === 401) expireLocal(); throw new Error(data.error || "Could not refresh inbox."); }
    state.messages = data.messages || []; renderMessages(state.messages);
    $("status").textContent = "Inbox updates automatically.";
  } catch(e) { if (state.address) $("status").textContent = "Waiting for connection…"; }
}
function renderMessages(messages) {
  $("count").textContent = messages.length;
  $("empty").hidden = messages.length > 0;
  $("messages").innerHTML = ""; $("detail").hidden = true;
  messages.forEach(m => {
    const button = document.createElement("button"); button.className = "message"; button.type = "button";
    const top = document.createElement("div"); top.className = "message-top";
    const sender = document.createElement("span"); sender.className = "sender"; sender.textContent = m.sender || "Unknown sender";
    const date = document.createElement("span"); date.className = "date"; date.textContent = new Date(m.receivedAt).toLocaleString();
    const subject = document.createElement("div"); subject.className = "subject"; subject.textContent = m.subject || "(No subject)";
    const preview = document.createElement("div"); preview.className = "preview"; preview.textContent = (m.body || "").replace(/\s+/g," ").slice(0,150);
    top.append(sender,date); button.append(top,subject,preview); button.addEventListener("click", () => openMessage(m)); $("messages").appendChild(button);
  });
}
function openMessage(m) {
  $("messages").hidden = true; $("empty").hidden = true; $("detail").hidden = false;
  $("detailMeta").textContent = `From: ${m.sender} · ${new Date(m.receivedAt).toLocaleString()}`;
  $("detailSubject").textContent = m.subject || "(No subject)";
  $("detailBody").textContent = m.body || "(Empty message)";
}
$("backBtn").addEventListener("click", () => { $("detail").hidden = true; $("messages").hidden = false; $("empty").hidden = state.messages.length > 0; });
$("createBtn").addEventListener("click", createInbox);
$("copyBtn").addEventListener("click", copyAddress);
$("refreshBtn").addEventListener("click", () => { pollMessages(); toast("Inbox refreshed."); });
$("deleteBtn").addEventListener("click", async () => {
  if (!state.address || !confirm("Delete this inbox and its messages? This cannot be undone.")) return;
  try { await fetch(`/api/inboxes/${encodeURIComponent(state.address)}`, {method:"DELETE",headers:authHeaders()}); }
  catch {}
  stopPolling(); state.address = state.token = state.expiresAt = null; state.messages = []; save(); showAddress(); renderMessages([]); $("status").textContent = "Inbox deleted."; toast("Inbox deleted.");
});
if (state.address && state.token && state.expiresAt > Date.now()) { showAddress(); startPolling(); }
else { state.address = state.token = state.expiresAt = null; save(); showAddress(); }
